package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ItemAdapter extends ArrayAdapter<Item> {

    public ItemAdapter(Context context, ArrayList<Item> items) {
        super(context, 0, items);
    }

    @Override
    @NonNull
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Item item = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.outline, parent, false);
        }

        TextView txtValue = convertView.findViewById(R.id.txtValue);
        TextView txtCost = convertView.findViewById(R.id.txtCost);
        TextView txtIncome = convertView.findViewById(R.id.txtIncome);
        TextView txtDate = convertView.findViewById(R.id.txtDate);

        if (item != null) {
            txtValue.setText(item.value != null ? item.value : "");
            txtCost.setText(String.valueOf(item.cost));
            txtIncome.setText(String.valueOf(item.income));
            txtDate.setText(item.date != null ? item.date : "");
        }

        return convertView;
    }

    public Item getItem(int position) {
        return super.getItem(position);
    }
}
