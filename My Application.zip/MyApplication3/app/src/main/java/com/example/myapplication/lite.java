package com.example.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;

public class lite extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyDatabase.db";
    private static final int DATABASE_VERSION = 3;

    public lite(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "value TEXT," +
                "cost REAL," +
                "income REAL," +
                "date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS items");
        onCreate(db);
    }


    public void insertItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("value", item.value);
        values.put("cost", item.cost);
        values.put("income", item.income);
        values.put("date", item.date);
        db.insert("items", null, values);
    }


    public ArrayList<Item> getAllItems() {
        ArrayList<Item> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM items", null);

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                item.value = cursor.getString(cursor.getColumnIndexOrThrow("value"));
                item.cost = cursor.getDouble(cursor.getColumnIndexOrThrow("cost"));
                item.income = cursor.getDouble(cursor.getColumnIndexOrThrow("income"));
                item.date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                items.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("items", "id=?", new String[]{String.valueOf(id)});
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("value", item.value);
        values.put("cost", item.cost);
        values.put("income", item.income);
        values.put("date", item.date);
        db.update("items", values, "id=?", new String[]{String.valueOf(item.id)});
    }
}
