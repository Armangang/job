package com.example.myapplication;

public class Item {
    public int id;
    public String value;
    public double cost;
    public double income;
    public String date;


    public Item() {
    }

    public Item(String value, double cost, double income, String date) {
        this.value = value;
        this.cost = cost;
        this.income = income;
        this.date = date;
    }


}