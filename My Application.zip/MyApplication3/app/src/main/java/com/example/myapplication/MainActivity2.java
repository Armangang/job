package com.example.myapplication;

//import static androidx.core.content.ContextCompat.startActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.CheckBox;
//import android.widget.DatePicker;

import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.widget.Toast;

//import java.util.Calendar;

import java.util.ArrayList;
import java.util.Collections;
//import java.util.Comparator;


public class MainActivity2 extends AppCompatActivity {

    private ArrayList<Item> items;
    private ItemAdapter adapter;
    private ListView listView;
    private Button btnAdd, btnFilter, btnChart;
    private SearchView searchView;
    private lite db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        quantification();
        setupList();
        setupListeners();
        loadAllItems();
    }

    private void quantification() {
        listView = findViewById(R.id.mylist);
        btnAdd = findViewById(R.id.button2);
        btnFilter = findViewById(R.id.filter);
        btnChart = findViewById(R.id.btnChart);
        searchView = findViewById(R.id.searchview);
        db = new lite(this);
    }

    private void setupList() {
        ArrayList<Item> originalItems = db.getAllItems();
        items = new ArrayList<>(originalItems);
        adapter = new ItemAdapter(this, items);
        listView.setAdapter(adapter);
    }

    private void setupListeners() {

        btnAdd.setOnClickListener(v -> showAddDialog());


        btnFilter.setOnClickListener(v -> showFilterDialog());


        btnChart.setOnClickListener(v -> {

            float income = 0f;
            float expense = 0f;

            for (Item item : allItemsCache) {
                income += (float) item.income;
                expense += (float) item.cost;
            }

            Intent intent = new Intent(MainActivity2.this, Chart.class);
            intent.putExtra("income", income);
            intent.putExtra("expense", expense);
            startActivity(intent);
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                NumBySearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                NumBySearch(newText);
                return true;
            }
        });


        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            showPopupMenu(view, position);
            return true;
        });
    }


    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.layout, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        dialog.show();

        EditText editValue = dialogView.findViewById(R.id.editValue);
        EditText editCost = dialogView.findViewById(R.id.editCost);
        EditText editIncome = dialogView.findViewById(R.id.editIncome);
        EditText editDate = dialogView.findViewById(R.id.editDate);
        Button btnSave = dialogView.findViewById(R.id.btnSave);

        btnSave.setOnClickListener(view -> {
            String value = editValue.getText().toString();
            if (value.matches("\\d+")) {
                Toast.makeText(this, "نمی توانید فقط ار عدد برای نام مقدار استفاده کنید", Toast.LENGTH_SHORT).show();
                return;
            } else if (value.matches(".*([a-zA-Z])\\1{2,}.*") || (value.length() >= 10) || (value.length() < 3)) {
                Toast.makeText(this, "در انتخاب نام برای مقدار خود دقت کنید", Toast.LENGTH_SHORT).show();
                return;
            }

            String costText = editCost.getText().toString();
            String incomeText = editIncome.getText().toString();

            double cost = costText.trim().isEmpty() ? 0.0 : Double.parseDouble(costText);
            if (cost >= 10000.0) {
                Toast.makeText(this, "مقدار هزینه بیشتر دامنه عددی است", Toast.LENGTH_SHORT).show();
                return;
            }
            double income = incomeText.trim().isEmpty() ? 0.0 : Double.parseDouble(incomeText);
            if (income >= 10000.0) {
                Toast.makeText(this, "مقدار درآمد بیشتر دامنه عددی است", Toast.LENGTH_SHORT).show();
                return;
            }


            String date = editDate.getText().toString();


            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                Toast.makeText(this, "لطفا در وارد کردن تاریخ دقت کنید", Toast.LENGTH_SHORT).show();
                return;
            }


            String[] parts = date.split("-");

            int month = Integer.parseInt(parts[1]);
            int day = Integer.parseInt(parts[2]);


            if (month < 1 || month > 12) {
                Toast.makeText(this, "ماه باید بین 1 تا 12 باشد", Toast.LENGTH_SHORT).show();
                return;
            }


            if (day < 1 || day > 30) {
                Toast.makeText(this, "روز باید بین 1 تا 30 باشد", Toast.LENGTH_SHORT).show();
                return;
            }

            Item newItem = new Item(value, cost, income, date);

            db.insertItem(newItem);
            refreshList();
            dialog.dismiss();
            Toast.makeText(this, "آیتم با موفقیت به لیست اضافه شد", Toast.LENGTH_SHORT).show();

        });
    }


    private void showEditDialog(Item item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.layout, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        dialog.show();

        EditText editValue = dialogView.findViewById(R.id.editValue);
        EditText editCost = dialogView.findViewById(R.id.editCost);
        EditText editIncome = dialogView.findViewById(R.id.editIncome);
        EditText editDate = dialogView.findViewById(R.id.editDate);
        Button btnSave = dialogView.findViewById(R.id.btnSave);


        editValue.setText(item.value);
        editCost.setText(String.valueOf(item.cost));
        editIncome.setText(String.valueOf(item.income));
        editDate.setText(item.date);

        btnSave.setOnClickListener(view -> {
            String value = editValue.getText().toString();
            if (value.matches(".*([a-zA-Z])\\1{2,}.*") || (value.length() >= 10) || (value.length() < 3) || value.matches("\\d+")) {
                Toast.makeText(this, "در انتخاب نام برای مقدار خود دقت کنید", Toast.LENGTH_SHORT).show();
                return;
            }

            String costText = editCost.getText().toString();

            if (costText.contains(".")) {
                int index = costText.indexOf(".");
                int decimals = costText.length() - index - 1;

                if (decimals > 2) {
                    Toast.makeText(this, "نمی توانید بیشتر از دو رقم اعشار بزنید", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            String incomeText = editIncome.getText().toString();
            if (incomeText.contains(".")) {
                int index = incomeText.indexOf(".");
                int decimals = incomeText.length() - index - 1;

                if (decimals > 2) {
                    Toast.makeText(this, "نمی توانید بیشتر از دو رقم اعشار بزنید", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            double cost = costText.trim().isEmpty() ? 0.0 : Double.parseDouble(costText);
            if (cost >= 10000.0) {
                Toast.makeText(this, "مقدار هزینه بیشتر دامنه عددی است", Toast.LENGTH_SHORT).show();
                return;
            }
            double income = incomeText.trim().isEmpty() ? 0.0 : Double.parseDouble(incomeText);
            if (income >= 10000.0) {
                Toast.makeText(this, "مقدار درآمد بیشتر دامنه عددی است", Toast.LENGTH_SHORT).show();
                return;
            }

            String date = editDate.getText().toString();


            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                Toast.makeText(this, "لطفا در وارد کردن تاریخ دقت کنید", Toast.LENGTH_SHORT).show();
                return;
            }


            String[] parts = date.split("-");

            int month = Integer.parseInt(parts[1]);
            int day = Integer.parseInt(parts[2]);


            if (month < 1 || month > 12) {
                Toast.makeText(this, "ماه باید بین 1 تا 12 باشد", Toast.LENGTH_SHORT).show();
                return;
            }


            if (day < 1 || day > 30) {
                Toast.makeText(this, "روز باید بین 1 تا 30 باشد", Toast.LENGTH_SHORT).show();
                return;
            }

            item.value = value;
            item.cost = cost;
            item.income = income;
            item.date = date;


            db.updateItem(item);
            refreshList();
            dialog.dismiss();
            Toast.makeText(this, "آیتم با موفقیت ویرایش شد", Toast.LENGTH_SHORT).show();
        });
    }


    ArrayList<Item> allItemsCache = new ArrayList<>();


    private void loadAllItems() {
        allItemsCache.clear();
        allItemsCache.addAll(db.getAllItems());
        items.clear();
        items.addAll(allItemsCache);
        adapter.notifyDataSetChanged();

    }


    private void applyFilter(boolean showTotal, boolean sortByCost, boolean sortByIncome) {
        ArrayList<Item> filtered = new ArrayList<>(allItemsCache);


        if (sortByIncome) {
            Collections.sort(filtered, (i1, i2) -> Double.compare(i2.income, i1.income));
        } else if (sortByCost) {
            Collections.sort(filtered, (i1, i2) -> Double.compare(i2.cost, i1.cost));
        }

        if (!showTotal && !sortByCost && !sortByIncome) {
            items.clear();
            items.addAll(allItemsCache);
            adapter.notifyDataSetChanged();
            return;
        }


        double totalCost = 0.0;
        double totalIncome = 0.0;
        for (Item item : filtered) {
            totalCost += item.cost;
            totalIncome += item.income;
        }


        if (showTotal) {
            int roundedCost = (int) totalCost;
            int roundedIncome = (int) totalIncome;

            String summaryValue = "مجموع هزینه‌ها: " + roundedCost + " | مجموع درآمدها: " + roundedIncome;

            Item summaryItem = new Item(summaryValue, roundedCost, roundedIncome, "summary");
            filtered.add(0, summaryItem);
        }


        items.clear();
        items.addAll(filtered);
        adapter.notifyDataSetChanged();
    }


    private boolean filterShowTotal = false;
    private boolean filterSortByCost = false;
    private boolean filterSortByIncome = false;

    private void showFilterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.filter, null);
        builder.setView(view);

        CheckBox chkTotalMonth = view.findViewById(R.id.chkTotalMonth);
        CheckBox chkCostHigh = view.findViewById(R.id.chkconsthigh);
        CheckBox chkIncomeHigh = view.findViewById(R.id.chkincomehigh);
        Button btnApply = view.findViewById(R.id.btnApplyFilter);


        chkTotalMonth.setChecked(filterShowTotal);
        chkCostHigh.setChecked(filterSortByCost);
        chkIncomeHigh.setChecked(filterSortByIncome);

        AlertDialog dialog = builder.create();
        dialog.show();

        btnApply.setOnClickListener(v -> {

            filterShowTotal = chkTotalMonth.isChecked();
            filterSortByCost = chkCostHigh.isChecked();
            filterSortByIncome = chkIncomeHigh.isChecked();


            applyFilter(filterShowTotal, filterSortByCost, filterSortByIncome);

            dialog.dismiss();
            Toast.makeText(this, "فیلتر اعمال شد ✅", Toast.LENGTH_SHORT).show();
        });
    }


    private void showPopupMenu(View view, int position) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.getMenuInflater().inflate(R.menu.holdmenu, popup.getMenu());

        popup.setOnMenuItemClickListener(menuItem -> {
            Item selectedItem = items.get(position);

            if (menuItem.getItemId() == R.id.action_edit) {
                showEditDialog(selectedItem);
                return true;
            } else if (menuItem.getItemId() == R.id.action_delete) {
                db.deleteItem(selectedItem.id);
                refreshList();
                return true;
            } else if (menuItem.getItemId() == R.id.action_description) {
                showDescription(selectedItem);
                return true;
            }
            return false;
        });

        popup.show();
    }

    private void showDescription(Item item) {

        String decision;
        String costText = item.cost + "$";
        double remain = item.income - item.cost;
        String remainText = String.format("%.2f", remain);


        if (item.cost == 0.0) {
            decision = "❌ هزینه رو صحیح وارد نکردی";
        } else if (item.income == 0.0) {
            decision = "❌ درآمد رو صحیح وارد نکردی";

        } else if (item.value.isEmpty()) {
            decision = " ❌ برای چه کالا یا مقداری این هزینه: " + costText + " رو وارد کردی";

        } else if (item.date.isEmpty()) {
            decision = " لطفا تاریخ دقیق خرید را وارد کن تا نهایی بشه";

        } else if (item.cost == item.income) {
            decision = "از این خرید هیچ سود و ضرری ثبت نشد چون مقادیر مشابه هست ";

        } else if (item.cost <= item.income) {
            decision = "✅ این خرید نسبت به درآمد شما ارزش خرید دارد.";

        } else if (item.cost >= item.income) {
            decision = "⚠️ این خرید بیشتر از درآمد شماست و ارزش خرید ندارد.";

        } else {
            decision = "اطلاعاتی راجب خریدی که انجام داده اید.";
        }


        String desc = "در تاریخ " + item.date +
                " شما " + item.value +
                " خریدی به مبلغ " + costText +
                " که " +
                "درآمد مرتبط به آن : " + item.income + "$" +
                "\n\n" +
                "باقی مانده پول: " + remainText + "$" +
                "\n\n" +
                decision;


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("توضیحات آیتم");
        builder.setMessage(desc);
        builder.setPositiveButton("فهمیدم", (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void refreshList() {
        items.clear();
        items.addAll(db.getAllItems());
        adapter.notifyDataSetChanged();
    }


    private void NumBySearch(String text) {
        ArrayList<Item> filtered = new ArrayList<>();
        for (Item item : db.getAllItems()) {
            try {
                double searchValue = Double.parseDouble(text);

                if (item.value.toLowerCase().contains(text.toLowerCase()) ||
                        item.date.toLowerCase().contains(text.toLowerCase()) ||
                        item.cost == searchValue ||
                        item.income == searchValue) {
                    filtered.add(item);
                }
            } catch (NumberFormatException e) {

                if (item.value.toLowerCase().contains(text.toLowerCase()) ||
                        item.date.toLowerCase().contains(text.toLowerCase())) {
                    filtered.add(item);
                }
            }

        }
        items.clear();
        items.addAll(filtered);
        adapter.notifyDataSetChanged();
    }
}