package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Chart extends AppCompatActivity {

    private PieChart pieChart;
    private BarChart barChart;
    private final ArrayList<Item> allItemsCache = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chartac);

        pieChart = findViewById(R.id.pieChart);
        barChart = findViewById(R.id.barChart);
        lite db = new lite(this);
        try (db) {
            allItemsCache.addAll(db.getAllItems());
        }

        setupPieChart();
        setupBarChart();

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

    }

    private void setupPieChart() {
        float totalIncome = 0f;
        float totalExpense = 0f;


        for (Item item : allItemsCache) {
            totalIncome += (float) item.income;
            totalExpense += (float) item.cost;

        }

        ArrayList<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(totalIncome, "درآمد"));
        entries.add(new PieEntry(totalExpense, "هزینه"));


        PieDataSet dataSet = new PieDataSet(entries, "گزارش مالی ماهانه");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        PieData data = new PieData(dataSet);

        pieChart.setData(data);
        pieChart.getDescription().setEnabled(false);
        pieChart.animateY(1000);
    }

    private void setupBarChart() {
        ArrayList<BarEntry> entries = new ArrayList<>();

        for (int day = 1; day <= 7; day++) {
            float dailyIncome = 0f;
            float dailyExpense = 0f;

            for (Item item : allItemsCache) {
                String[] parts = item.date.split("-");
                if (parts.length == 3) {
                    int itemDay = Integer.parseInt(parts[2]);
                    if (itemDay == day) {
                        dailyIncome += (float) item.income;
                        dailyExpense += (float) item.cost;
                    }
                }
            }

            entries.add(new BarEntry(day, new float[]{dailyExpense, dailyIncome}));
        }

        BarDataSet dataSet = new BarDataSet(entries, "هزینه و درآمد روزانه");
        dataSet.setColors(Color.RED, Color.GREEN);
        BarData data = new BarData(dataSet);

        barChart.setData(data);
        barChart.getDescription().setEnabled(false);
        barChart.setFitBars(true);
        barChart.animateY(1000);
    }
}
